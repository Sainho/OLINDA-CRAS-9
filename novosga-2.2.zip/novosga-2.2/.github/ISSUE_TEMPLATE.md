| Q                | A
| ---------------- | -----
| Bug report?      | yes/no
| Feature request? | yes/no
| Novo SGA version | x.y.z
| PHP version      | x.y.z
| Database version | MySQL 5.7/PostgreSQL 15
| Platform/OS      | Linux/Windows

<!--
- Please fill in this template according to your issue.
- Replace this comment by the description of your issue.
-->
